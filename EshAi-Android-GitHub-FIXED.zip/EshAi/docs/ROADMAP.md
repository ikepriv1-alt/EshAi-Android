# EshAi integration notes

## Conversion module

`files/UniversalConverter.kt` is a local converter for a deliberately constrained set of source/target pairs. It parses OOXML as ZIP/XML and uses PDFBox-Android for text extraction. It is not a full fidelity Office renderer.

Recommended future improvements:
- Add conversion registry with per-pair capability declarations.
- Add robust RFC 4180 CSV parser and formula-aware XLSX handling.
- Add OCR for image-based PDFs and photos.
- Add an Office-compatible renderer if fidelity is required; verify Android compatibility and licensing.
- Add media transcoding with MediaCodec/FFmpeg only after validating ABI size and LGPL/GPL obligations.
- Add file-size limits and streaming to avoid large `readBytes()` allocations.

## Local AI

`ai/LocalAiEngine.kt` defines the interface, and `RuntimeNotInstalledEngine` fails explicitly. It is intentionally not a fake LLM. Integrate a real runtime and model weights, and keep all inference local.

## Chess

`chess/StockfishUciProtocol.kt` generates UCI command sequences and parses engine info. It does not launch an engine or validate legal moves. Add a native Stockfish build, an Android JNI transport, and a chess rules/PGN parser before claiming analysis works.

## Speech

Android `RecognizerIntent.EXTRA_PREFER_OFFLINE` is a request, not a guarantee. Whisper.cpp plus a compatible local model is required for reliable offline transcription.
