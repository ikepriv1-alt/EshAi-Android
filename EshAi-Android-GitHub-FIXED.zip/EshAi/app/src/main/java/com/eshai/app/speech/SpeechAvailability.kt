package com.eshai.app.speech

/** Explains Android speech recognition's offline limitations to the UI. */
data class SpeechMode(val label: String, val guaranteedOffline: Boolean, val detail: String)

object SpeechAvailability {
    val androidRecognizer = SpeechMode(
        label = "Pengenal suara Android",
        guaranteedOffline = false,
        detail = "Permintaan offline dapat diabaikan oleh layanan speech perangkat. Untuk offline yang terjamin, integrasikan Whisper.cpp beserta model lokal yang sudah dipasang."
    )
}
