package com.eshai.app.chess

/** Pure UCI protocol helpers. A real engine transport/native Stockfish binary is still required. */
object StockfishUciProtocol {
    fun newGameCommands(): List<String> = listOf("uci", "isready", "ucinewgame", "isready")

    fun analyseFen(fen: String, depth: Int): List<String> {
        require(depth in 1..40) { "Depth harus berada antara 1 dan 40." }
        require(fen.trim().split(Regex("\\s+")).size >= 4) { "FEN tidak valid atau tidak lengkap." }
        return listOf("position fen ${fen.trim()}", "go depth $depth")
    }

    fun analysePgnMoves(uciMoves: List<String>, depth: Int): List<String> {
        require(depth in 1..40) { "Depth harus berada antara 1 dan 40." }
        require(uciMoves.all { it.matches(Regex("[a-h][1-8][a-h][1-8][qrbn]?")) }) {
            "Langkah harus dalam format UCI, misalnya e2e4 atau e7e8q. PGN SAN perlu diparse terlebih dahulu."
        }
        val moves = uciMoves.joinToString(" ")
        return listOf("position startpos moves $moves", "go depth $depth")
    }

    fun parseInfoLine(line: String): EngineInfo? {
        if (!line.startsWith("info ")) return null
        val tokens = line.split(Regex("\\s+"))
        val depth = tokens.indexOf("depth").takeIf { it >= 0 }?.let { tokens.getOrNull(it + 1)?.toIntOrNull() }
        val scoreIndex = tokens.indexOf("score")
        val scoreType = tokens.getOrNull(scoreIndex + 1)
        val score = tokens.getOrNull(scoreIndex + 2)?.toIntOrNull()
        val pvIndex = tokens.indexOf("pv")
        val pv = if (pvIndex >= 0) tokens.drop(pvIndex + 1).takeWhile { it != "string" } else emptyList()
        return EngineInfo(depth, scoreType, score, pv)
    }
}

data class EngineInfo(val depth: Int?, val scoreType: String?, val score: Int?, val principalVariation: List<String>)
