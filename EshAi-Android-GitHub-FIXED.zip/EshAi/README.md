# EshAi Android — Offline-first MVP 0.2.0

EshAi is an Android/Kotlin/Jetpack Compose project with a local file-conversion module and a GitHub Actions build workflow. It is designed to be extended with a real local LLM, offline speech model, and Stockfish engine.

## Included and implemented

- Dark minimal Compose UI with Chat, Chess Analyzer, and File Converter tabs.
- Android Storage Access Framework file selection and Save As flow.
- Local image conversion among PNG/JPG/WEBP for common bitmap formats.
- Local text conversions among TXT/MD/HTML/CSV/JSON/XML/LOG/FEN/PGN where the target is text/HTML/Markdown/PDF/DOCX/XLSX.
- PDF text extraction using PDFBox-Android; text-based PDF generation using Android `PdfDocument`.
- Basic DOCX text extraction and DOCX generation using OOXML ZIP/XML packages.
- Basic XLSX first-sheet to CSV extraction and simple CSV/text to XLSX generation.
- PPTX slide text extraction to TXT/HTML/MD/PDF/DOCX/XLSX.
- XML parser hardening against DOCTYPE/external entity expansion.
- Local UCI protocol helpers for Stockfish commands and parsing `info` lines.
- An explicit `LocalAiEngine` interface so a real on-device inference runtime can be connected without representing canned demo responses as generative AI.
- GitHub Actions workflow to build and upload a debug APK artifact.
- Logo SVG and development notes.

## Important functional limits

This ZIP is an expanded working codebase, **not a finished commercial-grade universal converter or a fully generative offline AI**. It does not bundle large model weights or a Stockfish Android engine binary, because these require selecting a compatible runtime/build, architecture, model license, and distribution method. The `LocalAiEngine` and UCI helpers are integration boundaries, not inference/engine implementations.

Current conversion limits:

- PDF text extraction works for text-based PDFs; scanned PDFs need OCR, which is not bundled.
- PDF output is rebuilt from extracted text and will not preserve original page layout, fonts, tables, or graphics.
- DOCX import/export handles basic paragraph text only; tables, images, styles, headers/footers, fields, and tracked changes are not preserved.
- XLSX reads only the first worksheet and supports basic cell values. CSV parsing/generation is deliberately basic; formulas, formatting, charts, multiple sheets, and quoted-comma parsing are not fully preserved.
- PPTX extraction collects text from slides; animations, images, speaker notes, and slide layout are not preserved.
- Arbitrary binary formats are not converted merely because the picker can select them. Unsupported source/target pairs return an error.
- Android's speech recognizer may ignore `EXTRA_PREFER_OFFLINE`; this is not guaranteed offline speech recognition. Integrate Whisper.cpp and ship/download its model separately for reliable offline transcription.
- Chess UCI helper code does not itself include the Stockfish engine or a complete chessboard/legal-move implementation.

## Build through GitHub

1. Create a repository named `EshAi`.
2. Extract this ZIP and upload the **contents** of the `EshAi` folder to the repository root (including `.github`).
3. Commit to the `main` branch.
4. Open the **Actions** tab and run `Build EshAi APK` (it also runs on push to `main`).
5. Download the `EshAi-debug-apk` artifact from a successful workflow run.
6. Extract the artifact ZIP and install the APK on an Android device. Enable installation from that source if Android prompts you.

A successful workflow run is the definitive build check; this development environment did not execute an Android Gradle build. If a dependency or SDK error occurs, open the Actions log and fix the first Gradle error before proceeding.

## Local build

Open the folder in Android Studio (JDK 17, Android SDK 35) and let Android Studio sync Gradle. Then run `assembleDebug` from the Gradle tool window or terminal.

## True offline AI integration checklist

1. Select a local inference runtime (LiteRT-LM or llama.cpp) with a maintained Android API.
2. Select a model that supports the target runtime, Android ABI, and Indonesian prompts; review its license.
3. Implement `LocalAiEngine` against that runtime and test on the actual target phone.
4. Add a model manager that imports/installs model files and checks storage/RAM before loading.
5. Add local context extraction/chunking for long documents and an OCR model for scanned PDFs/images.
6. For offline speech, integrate Whisper.cpp JNI and install a Whisper model separately.
7. For Chess Analyzer, integrate a native Stockfish Android build and a legal chess move/PGN parser; then connect UCI commands to the UI.
8. Test in airplane mode after all model/engine assets are installed.

## Privacy

The project declares no internet permission and the implemented converter runs locally. The system speech recognizer is invoked through Android and may use a provider with online processing depending on the device configuration. Do not claim complete offline operation until speech and model runtimes are integrated and verified in airplane mode.

## License

Review licenses for every dependency, model, and engine before redistributing the complete app. Stockfish is GPL-3.0; comply with its source-distribution obligations if bundled. Model licenses vary by model.
