package com.eshai.app.ai

/**
 * Runtime boundary for a genuinely local generative model.
 * A GGUF/LiteRT model file alone is not an inference engine; an implementation must bind
 * to a compatible native/runtime library. The starter deliberately fails explicitly instead
 * of pretending canned replies are generated AI.
 */
interface LocalAiEngine {
    val isReady: Boolean
    suspend fun load(modelPath: String)
    suspend fun generate(prompt: String, context: String = ""): String
    fun close()
}

class RuntimeNotInstalledEngine : LocalAiEngine {
    override val isReady: Boolean = false
    override suspend fun load(modelPath: String) {
        throw IllegalStateException(
            "Runtime LLM lokal belum dikonfigurasi. Tambahkan runtime LiteRT-LM/llama.cpp yang kompatibel dan model yang sesuai lisensinya."
        )
    }
    override suspend fun generate(prompt: String, context: String): String {
        throw IllegalStateException("Model AI generatif belum tersedia. Chat demo tidak boleh dianggap sebagai AI generatif.")
    }
    override fun close() = Unit
}
