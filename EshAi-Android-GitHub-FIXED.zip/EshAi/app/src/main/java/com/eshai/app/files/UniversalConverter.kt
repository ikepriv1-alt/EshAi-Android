package com.eshai.app.files

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory

/** Explicitly limited, local-only conversion service. Office formats are processed as OOXML packages. */
object UniversalConverter {
    data class Result(val bytes: ByteArray, val mimeType: String, val extension: String, val note: String = "")

    fun convert(context: Context, fileName: String, source: ByteArray, target: String): Result {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val normalizedTarget = target.uppercase()
        val text = when (ext) {
            "txt", "md", "csv", "html", "htm", "json", "xml", "log", "fen", "pgn" -> source.toString(Charsets.UTF_8)
            "docx" -> readDocx(source)
            "xlsx" -> readXlsxCsv(source)
            "pptx" -> readPptx(source)
            "pdf" -> readPdf(context, source)
            else -> null
        }
        return when (normalizedTarget) {
            "TXT" -> Result(requireText(text, ext).toByteArray(Charsets.UTF_8), "text/plain", "txt", "Teks diekstrak; tata letak asli tidak dipertahankan.")
            "MD" -> Result(textToMarkdown(requireText(text, ext)).toByteArray(Charsets.UTF_8), "text/markdown", "md")
            "HTML" -> Result(textToHtml(requireText(text, ext)).toByteArray(Charsets.UTF_8), "text/html", "html")
            "PDF" -> Result(createPdf(requireText(text, ext)), "application/pdf", "pdf", "PDF dibuat dari teks; tata letak dokumen sumber tidak dipertahankan.")
            "DOCX" -> Result(createDocx(requireText(text, ext)), "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx", "DOCX dibuat dari teks hasil ekstraksi; tata letak kompleks tidak dipertahankan.")
            "CSV" -> {
                val csv = when (ext) { "xlsx" -> text ?: ""; "csv" -> source.toString(Charsets.UTF_8); else -> requireText(text, ext) }
                Result(csv.toByteArray(Charsets.UTF_8), "text/csv", "csv")
            }
            "XLSX" -> Result(createXlsx(requireText(text, ext)), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx", "Spreadsheet dibuat dengan data teks satu kolom; format dan formula sumber tidak dipertahankan.")
            else -> throw IllegalArgumentException("Target .$normalizedTarget belum didukung oleh konverter ini.")
        }
    }

    private fun requireText(text: String?, ext: String): String = text
        ?: throw IllegalArgumentException("Sumber .$ext belum didukung untuk konversi dokumen. Format yang didukung: TXT, MD, CSV, HTML, JSON, XML, LOG, PDF, DOCX, XLSX, PPTX, PGN, FEN.")

    private fun readPdf(context: Context, bytes: ByteArray): String {
        PDFBoxResourceLoader.init(context)
        PDDocument.load(ByteArrayInputStream(bytes)).use { return PDFTextStripper().getText(it) }
    }

    private fun xmlFromZip(bytes: ByteArray, path: String): org.w3c.dom.Document? {
        val entries = unzip(bytes)
        val xml = entries[path] ?: return null
        val factory = DocumentBuilderFactory.newInstance().apply {
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            isXIncludeAware = false; isExpandEntityReferences = false
        }
        return factory.newDocumentBuilder().parse(ByteArrayInputStream(xml))
    }

    private fun readDocx(bytes: ByteArray): String {
        val doc = xmlFromZip(bytes, "word/document.xml") ?: throw IllegalArgumentException("DOCX tidak memiliki word/document.xml")
        val ns = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
        val paragraphs = doc.getElementsByTagNameNS(ns, "p")
        val out = StringBuilder()
        for (i in 0 until paragraphs.length) {
            val p = paragraphs.item(i) as Element
            val nodes = p.getElementsByTagNameNS(ns, "t")
            for (j in 0 until nodes.length) out.append(nodes.item(j).textContent)
            if (i < paragraphs.length - 1) out.append('\n')
        }
        return out.toString()
    }

    private fun readPptx(bytes: ByteArray): String {
        val entries = unzip(bytes)
        val slideNames = entries.keys.filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
            .sortedBy { it.substringAfter("slide").substringBefore(".").toIntOrNull() ?: 0 }
        if (slideNames.isEmpty()) throw IllegalArgumentException("Tidak ditemukan slide di PPTX.")
        return slideNames.mapIndexed { index, path ->
            val doc = xmlFromZip(bytes, path)!!
            val nodes = doc.getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/main", "t")
            val content = (0 until nodes.length).joinToString(" ") { nodes.item(it).textContent }
            "Slide ${index + 1}\n$content"
        }.joinToString("\n\n")
    }

    private fun readXlsxCsv(bytes: ByteArray): String {
        val entries = unzip(bytes)
        val shared = entries["xl/sharedStrings.xml"]?.let { xml ->
            val d = parseXml(xml); val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
            val si = d.getElementsByTagNameNS(ns, "si")
            (0 until si.length).map { idx ->
                val t = (si.item(idx) as Element).getElementsByTagNameNS(ns, "t")
                (0 until t.length).joinToString("") { t.item(it).textContent }
            }
        } ?: emptyList()
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: throw IllegalArgumentException("XLSX tidak memiliki sheet1.xml")
        val doc = parseXml(sheet)
        val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        val rows = doc.getElementsByTagNameNS(ns, "row")
        val output = mutableListOf<String>()
        for (r in 0 until rows.length) {
            val row = rows.item(r) as Element
            val cells = row.getElementsByTagNameNS(ns, "c")
            val values = mutableMapOf<Int, String>()
            var maxCol = -1
            for (c in 0 until cells.length) {
                val cell = cells.item(c) as Element
                val ref = cell.getAttribute("r")
                val col = ref.takeWhile { it.isLetter() }.fold(0) { acc, ch -> acc * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                if (col < 0) continue
                val vNode = cell.getElementsByTagNameNS(ns, "v")
                val raw = if (vNode.length > 0) vNode.item(0).textContent else ""
                val inline = cell.getElementsByTagNameNS(ns, "t")
                val value = when (cell.getAttribute("t")) {
                    "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                    "inlineStr" -> (0 until inline.length).joinToString("") { inline.item(it).textContent }
                    else -> raw
                }
                values[col] = value; maxCol = maxOf(maxCol, col)
            }
            output += (0..maxCol.coerceAtLeast(0)).joinToString(",") { csvEscape(values[it].orEmpty()) }
        }
        return output.joinToString("\n")
    }

    private fun parseXml(bytes: ByteArray): org.w3c.dom.Document {
        val f = DocumentBuilderFactory.newInstance().apply {
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            isXIncludeAware = false; isExpandEntityReferences = false
        }
        return f.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    private fun createPdf(text: String): ByteArray {
        val out = ByteArrayOutputStream(); val pdf = PdfDocument()
        val paint = Paint().apply { color = android.graphics.Color.BLACK; textSize = 11f; isAntiAlias = true }
        val width = 595; val height = 842; val margin = 40f; val lineHeight = 16f
        val lines = text.lines().flatMap { line -> wrapLine(line, 90) }.ifEmpty { listOf("") }
        var idx = 0; var pageNo = 1
        while (idx < lines.size) {
            val info = PdfDocument.PageInfo.Builder(width, height, pageNo++).create()
            val page = pdf.startPage(info); var y = margin + 12
            while (idx < lines.size && y < height - margin) { page.canvas.drawText(lines[idx++], margin, y, paint); y += lineHeight }
            pdf.finishPage(page)
        }
        pdf.writeTo(out); pdf.close(); return out.toByteArray()
    }

    private fun createDocx(text: String): ByteArray {
        val body = text.lines().joinToString("") { line -> "<w:p><w:r><w:t xml:space=\"preserve\">${xmlEscape(line)}</w:t></w:r></w:p>" }
        val document = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$body<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>"""
        val types = """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>"""
        val rels = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"""
        return zip(mapOf("[Content_Types].xml" to types, "_rels/.rels" to rels, "word/document.xml" to document))
    }

    private fun createXlsx(text: String): ByteArray {
        val rows = text.lines().map { it.split(',') }
        val sheetRows = rows.mapIndexed { ri, row -> "<row r=\"${ri + 1}\">" + row.mapIndexed { ci, value -> "<c r=\"${columnName(ci + 1)}${ri + 1}\" t=\"inlineStr\"><is><t>${xmlEscape(value)}</t></is></c>" }.joinToString("") + "</row>" }.joinToString("")
        val sheet = """<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$sheetRows</sheetData></worksheet>"""
        val workbook = """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>"""
        val rootRels = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
        val wbRels = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>"""
        val types = """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>"""
        return zip(mapOf("[Content_Types].xml" to types, "_rels/.rels" to rootRels, "xl/workbook.xml" to workbook, "xl/_rels/workbook.xml.rels" to wbRels, "xl/worksheets/sheet1.xml" to sheet))
    }

    private fun unzip(bytes: ByteArray): Map<String, ByteArray> {
        val map = linkedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            while (true) { val entry = zis.nextEntry ?: break; if (!entry.isDirectory) map[entry.name] = zis.readBytes(); zis.closeEntry() }
        }
        return map
    }
    private fun zip(entries: Map<String, String>): ByteArray = zipBytes(entries.mapValues { it.value.toByteArray(Charsets.UTF_8) })
    private fun zipBytes(entries: Map<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream(); ZipOutputStream(out).use { zos -> entries.forEach { (name, bytes) -> zos.putNextEntry(ZipEntry(name)); zos.write(bytes); zos.closeEntry() } }; return out.toByteArray()
    }
    private fun textToMarkdown(text: String) = text.lines().joinToString("\n") { if (it.isBlank()) "" else it }
    private fun textToHtml(text: String) = "<!doctype html><html><head><meta charset=\"utf-8\"></head><body><pre>${htmlEscape(text)}</pre></body></html>"
    private fun htmlEscape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun xmlEscape(s: String) = htmlEscape(s).replace("\"", "&quot;").replace("'", "&apos;")
    private fun csvEscape(s: String) = if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"${s.replace("\"", "\"\"")}\"" else s
    private fun columnName(n: Int): String { var x = n; val s = StringBuilder(); while (x > 0) { val r = (x - 1) % 26; s.append(('A'.code + r).toChar()); x = (x - 1) / 26 }; return s.reverse().toString() }
    private fun wrapLine(line: String, max: Int): List<String> = if (line.length <= max) listOf(line) else line.chunked(max)
}
